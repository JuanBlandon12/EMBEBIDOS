#include <Arduino.h>
#include <WiFi.h>

const char * ssid = "Blandon_01";
const char * pass = "Jjb1234";
const char *host = "dweet.io";
const int port = 80; // Puerto por defecto del servicio web

void setup(){
  Serial.begin(115200);
  WiFi.begin(ssid, pass); // Inicializar modulo WIFI y que se vincule a la red indicada en el ssid
  Serial.print("Intentando Conexion");
  while (WiFi.status() != WL_CONNECTED){
    Serial.print(".");
    delay(1000);
  }
  Serial.println("Conectado");
  Serial.print("Direccion IP: ");
  Serial.println(WiFi.localIP());

  pinMode(2, OUTPUT);    // Configurar pin 2 como salida
  digitalWrite(2, HIGH); // Encender Led
}

void loop()
{
  WiFiClient cliente; // Objeto que realiza peticiones a un socket servidor

  if (!cliente.connect(host, port))
  {
    Serial.println("Conexion Fallida al servidor");
    delay(1000);
    return;
  }

  // Si llega a este linea es porque si hubo conexion con el servidor
  // Ahora tenemos un flujo de transmision y otro de recepcion
  float humedad = random(0,100); 
  float temperatura = random(0,100);
  


  // Enviamos la peticion en  protocolo http al servidor
 
  

  // Si se llega a este punto es porque se recibieron datos del servidor (cliente.available() !=0)
  while (cliente.available()){
    String linea = cliente.readStringUntil('\r'); // Lea un string hasta que encuentre el caracter
    Serial.println(linea);
  }

  Serial.println("Fin de conexion al servidor");
  cliente.stop();
  delay(5000); 
}