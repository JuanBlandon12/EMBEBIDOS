#include <Arduino.h>
#include  <WiFi.h>

const char * ssid = "JUANDAVID";
const char * pass = "123456789";
const char * host = "www.google.com";
const int port = 80;



/**
* @brief Funcion que inicializa el dispositivo
* Puerto serial(velocidad)
* Direcciones de pines de entrada y salida
* Se pueden crear objetos que representan sensores, dispositivos wifi y objetos de librerias externas
*/


void setup() {
  Serial.begin(115200); //configuramos a 115200 bits por segundo
  WiFi.begin(ssid, pass); //Inicializamos el modulo Wifi y que se vincule a la red indicada en el ssid
  while(WiFi.status() != WL_CONNECTED){
    Serial.print(".");
    delay(1000);
  }
  Serial.println(" Conectado!");
  Serial.print("Direccion IP: ");
  Serial.println(WiFi.localIP());

  pinMode(2, OUTPUT); //Configuramos el pin 2 como salida
  digitalWrite(2, HIGH); //Encendemos el LED 
}

void loop() {
  WiFiClient cliente; //Objeto que realiza peticiones a un socket servidor
  
  if(!cliente.connect(host, port)){
    Serial.println("Conexion fallida al servidor");
    delay(1000);
    return;
  }

  //Si llega a esta linea es por que si hubo conexion con el servidor
  //Ahora tenemos un flujo de transmision y otro de recepcion
  
  String request = String("GET / HTTP/1.1\r\n") + "Host: "+host+ "\r\n"+"Connection: close\r\n\r\n";

 //Enviamos la peticion en protocolo http al servidor
  cliente.print(request);

  unsigned long inicio = millis();
  while(cliente.available() == 0){
    if(millis() - inicio > 5000){
      Serial.print("Tiempo de espera del servidor agotado");
      cliente.stop();
      return;
    }
  }

  //Si se llega a este punto es por que se recibieron datos del servidor (cliente.available() != 0)

  while(cliente.available()){
    String linea = cliente.readStringUntil('\r'); //Lea un string hasta que encuentre el caracter enter
    Serial.println(linea);
  }

  Serial.println("Fin de la conexion al servidor");
  cliente.stop();
  delay(5000); //para evitar que se hagan muchas peticiones al servidor y nos metan en un back list(ban)



/*delay(500); //Retardo de 500ms
  digitalWrite(2, LOW); //Apagar el Led
  delay(500);
  digitalWrite(2, HIGH); //Encender el LED*/
}