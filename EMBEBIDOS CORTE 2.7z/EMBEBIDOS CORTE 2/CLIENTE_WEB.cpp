#include <WiFi.h>
#include <ESPAsyncWebClient.h>

const char* ssid = "BLANDON";      // Nombre de tu red WiFi
const char* password = "123JBG";  // Contraseña de tu red WiFi
const char* serverAddress = "www.ejemplo.com";  // Dirección del servidor al que deseas hacer la solicitud

void setup() {
  Serial.begin(115200);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Conectando a WiFi...");
  }

  Serial.println("Conectado a la red WiFi");

  // Crear un cliente web
  AsyncWebClient client;

  // Hacer una solicitud GET al servidor
  if (client.connect(serverAddress, 80)) {
    Serial.println("Solicitud HTTP enviada");
    client.print("GET / HTTP/1.1\r\n");
    client.print("Host: ");
    client.print(serverAddress);
    client.print("\r\n");
    client.print("Connection: close\r\n\r\n");
  } else {
    Serial.println("Error al conectar al servidor");
  }

  // Esperar a que haya datos disponibles o se agote el tiempo de espera
  while (client.connected() && !client.available()) delay(10);

  // Leer y mostrar la respuesta del servidor en el monitor serial
  while (client.available()) {
    String line = client.readStringUntil('\r');
    Serial.print(line);
  }

  // Cerrar la conexión
  client.stop();
}

void loop() {
  // Nada aquí por ahora
}
