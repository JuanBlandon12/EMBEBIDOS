#include <WiFi.h>
#include <ESPAsyncWebServer.h>

const char *ssid = "BLANDON"; // Nombre de tu red WiFi
const char *password = "123JBG"; // Contraseña de tu red WiFi
int ledPin = 13; // Pin del LED

AsyncWebServer server(80);

void setup() {
  pinMode(ledPin, OUTPUT);
  Serial.begin(115200);

  // Conectar a la red WiFi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Conectando a WiFi...");
  }
  Serial.println("Conectado a la red WiFi");

  // Manejador para la página principal
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    String html = "<html><body><h1>Control de LED</h1>";
    html += "<p><a href='/encender'>Encender LED</a></p>";
    html += "<p><a href='/apagar'>Apagar LED</a></p>";
    html += "</body></html>";
    request->send(200, "text/html", html);
  });

  // Manejador para encender el LED
  server.on("/encender", HTTP_GET, [](AsyncWebServerRequest *request){
    digitalWrite(ledPin, HIGH);
    request->send(200, "text/plain", "LED encendido");
  });

  // Manejador para apagar el LED
  server.on("/apagar", HTTP_GET, [](AsyncWebServerRequest *request){
    digitalWrite(ledPin, LOW);
    request->send(200, "text/plain", "LED apagado");
  });

  // Iniciar el servidor
  server.begin();
}

void loop() {
  // Nada aquí por ahora
}
